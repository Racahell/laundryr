Backend PHP native siap ditaruh di XAMPP.

Lokasi source project:
- C:\Users\User\AndroidStudioProjects\laundryr\perancangan\backend\php

Taruh ke XAMPP:
- C:\xampp\htdocs\penjualanmobil

Langkah:
1. Copy semua isi folder `php` ke `C:\xampp\htdocs\penjualanmobil`
2. Copy `.env.example` menjadi `.env`
3. Import database: `mysql -u root -p < db/schema.sql`
4. Start Apache dan MySQL di XAMPP

Base URL Android:
- http://192.168.182.155/penjualanmobil/index.php/
