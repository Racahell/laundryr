<?php

declare(strict_types=1);

require_once __DIR__ . '/src/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$baseDir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');

if ($baseDir !== '' && $baseDir !== '/' && str_starts_with($path, $baseDir)) {
    $path = substr($path, strlen($baseDir));
    $path = $path === '' ? '/' : $path;
}

if (str_starts_with($path, '/index.php')) {
    $path = substr($path, strlen('/index.php'));
    $path = $path === '' ? '/' : $path;
}

$path = rtrim($path, '/');
$path = $path === '' ? '/' : $path;

try {
    if ($method === 'GET' && $path === '/health') {
        jsonResponse(['status' => 'ok', 'app' => 'laundryr-php']);
    }

    if ($method === 'POST' && $path === '/api/v1/auth/register') {
        $data = jsonBody();
        foreach (['name', 'email', 'phone', 'password'] as $key) {
            if (!isset($data[$key]) || trim((string) $data[$key]) === '') {
                jsonResponse(['message' => $key . ' wajib diisi'], 422);
            }
        }

        $check = db()->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
        $check->execute(['email' => strtolower(trim((string) $data['email']))]);
        if ($check->fetch()) {
            jsonResponse(['message' => 'Email sudah terdaftar'], 422);
        }

        db()->beginTransaction();
        $userStmt = db()->prepare(
            'INSERT INTO users (name, email, phone, role, password, created_at, updated_at)
             VALUES (:name, :email, :phone, :role, :password, NOW(), NOW())'
        );
        $userStmt->execute([
            'name' => trim((string) $data['name']),
            'email' => strtolower(trim((string) $data['email'])),
            'phone' => trim((string) $data['phone']),
            'role' => 'customer',
            'password' => password_hash((string) $data['password'], PASSWORD_BCRYPT),
        ]);

        $userId = (int) db()->lastInsertId();

        $customerStmt = db()->prepare(
            'INSERT INTO customers (user_id, name, phone, address, created_at, updated_at)
             VALUES (:user_id, :name, :phone, :address, NOW(), NOW())'
        );
        $customerStmt->execute([
            'user_id' => $userId,
            'name' => trim((string) $data['name']),
            'phone' => trim((string) $data['phone']),
            'address' => isset($data['address']) ? trim((string) $data['address']) : null,
        ]);

        db()->commit();

        $user = [
            'id' => $userId,
            'name' => trim((string) $data['name']),
            'email' => strtolower(trim((string) $data['email'])),
            'phone' => trim((string) $data['phone']),
            'role' => 'customer',
        ];

        jsonResponse(['token' => tokenForUser($userId), 'user' => userDto($user)], 201);
    }

    if ($method === 'POST' && $path === '/api/v1/auth/login') {
        $data = jsonBody();
        foreach (['email', 'password'] as $key) {
            if (!isset($data[$key]) || trim((string) $data[$key]) === '') {
                jsonResponse(['message' => $key . ' wajib diisi'], 422);
            }
        }

        $stmt = db()->prepare('SELECT id, name, email, phone, role, password FROM users WHERE email = :email LIMIT 1');
        $stmt->execute(['email' => strtolower(trim((string) $data['email']))]);
        $user = $stmt->fetch();

        if (!$user || !password_verify((string) $data['password'], (string) $user['password'])) {
            jsonResponse(['message' => 'Email atau password salah'], 422);
        }

        jsonResponse([
            'token' => tokenForUser((int) $user['id']),
            'user' => userDto($user),
        ]);
    }

    if ($method === 'POST' && $path === '/api/v1/auth/logout') {
        $auth = requireAuth();
        $stmt = db()->prepare('UPDATE api_tokens SET revoked_at = NOW(), updated_at = NOW() WHERE id = :id');
        $stmt->execute(['id' => $auth['token_id']]);
        jsonResponse(['message' => 'Logout berhasil']);
    }

    if ($method === 'GET' && $path === '/api/v1/me') {
        $auth = requireAuth();
        jsonResponse(userDto($auth));
    }

    if ($method === 'GET' && $path === '/api/v1/special-item-categories') {
        requireAuth();
        $stmt = db()->query('SELECT id, name, unit, price_per_item, is_active FROM special_item_categories ORDER BY name ASC');
        $rows = $stmt->fetchAll();
        $data = array_map(static fn(array $row): array => [
            'id' => (int) $row['id'],
            'name' => $row['name'],
            'unit' => $row['unit'],
            'price_per_item' => (int) $row['price_per_item'],
            'is_active' => (bool) $row['is_active'],
        ], $rows);

        jsonResponse($data);
    }

    if ($method === 'GET' && $path === '/api/v1/orders') {
        $auth = requireAuth();

        if ($auth['role'] === 'customer') {
            $customerId = findCustomerIdByUserId((int) $auth['id']);
            if ($customerId === null) {
                jsonResponse([]);
            }
            $stmt = db()->prepare('SELECT id FROM orders WHERE customer_id = :customer_id ORDER BY id DESC');
            $stmt->execute(['customer_id' => $customerId]);
            $rows = $stmt->fetchAll();
        } else {
            $stmt = db()->query('SELECT id FROM orders ORDER BY id DESC');
            $rows = $stmt->fetchAll();
        }

        $orders = array_map(static fn(array $row): array => orderDto((int) $row['id']), $rows);
        jsonResponse($orders);
    }

    if ($method === 'POST' && $path === '/api/v1/orders') {
        $auth = requireAuth();
        requireRole($auth, ['staff']);

        $data = jsonBody();
        if (!isset($data['service_type_id'])) {
            jsonResponse(['message' => 'service_type_id wajib diisi'], 422);
        }

        $serviceStmt = db()->prepare('SELECT id, code FROM service_types WHERE id = :id LIMIT 1');
        $serviceStmt->execute(['id' => (int) $data['service_type_id']]);
        $service = $serviceStmt->fetch();
        if (!$service) {
            jsonResponse(['message' => 'service_type_id tidak valid'], 422);
        }

        $weight = isset($data['laundry_weight_kg']) ? (float) $data['laundry_weight_kg'] : 0.0;

        $priceStmt = db()->prepare(
            'SELECT price_per_kg FROM service_prices
             WHERE service_type_id = :service_type_id AND effective_from <= CURDATE()
             ORDER BY effective_from DESC
             LIMIT 1'
        );
        $priceStmt->execute(['service_type_id' => (int) $service['id']]);
        $price = $priceStmt->fetch();
        $pricePerKg = $price ? (int) $price['price_per_kg'] : ((string) $service['code'] === 'SETRIKA_SAJA' ? 6000 : 7000);

        $subtotalKg = (int) round($weight * $pricePerKg);
        $customerId = null;

        db()->beginTransaction();

        if (isset($data['customer_id'])) {
            $customerId = (int) $data['customer_id'];
        } else {
            $customer = $data['customer'] ?? null;
            if (!is_array($customer) || empty($customer['name']) || empty($customer['phone'])) {
                db()->rollBack();
                jsonResponse(['message' => 'Data customer wajib diisi'], 422);
            }

            $newCustomerStmt = db()->prepare(
                'INSERT INTO customers (name, phone, address, created_at, updated_at)
                 VALUES (:name, :phone, :address, NOW(), NOW())'
            );
            $newCustomerStmt->execute([
                'name' => trim((string) $customer['name']),
                'phone' => trim((string) $customer['phone']),
                'address' => isset($customer['address']) ? trim((string) $customer['address']) : null,
            ]);
            $customerId = (int) db()->lastInsertId();
        }

        $orderStmt = db()->prepare(
            'INSERT INTO orders (
                invoice_number, customer_id, created_by, service_type_id, laundry_weight_kg,
                price_per_kg_snapshot, subtotal_kg, subtotal_special, grand_total,
                payment_status, current_status, notes, created_at, updated_at
            ) VALUES (
                :invoice_number, :customer_id, :created_by, :service_type_id, :laundry_weight_kg,
                :price_per_kg_snapshot, :subtotal_kg, 0, :grand_total,
                :payment_status, :current_status, :notes, NOW(), NOW()
            )'
        );
        $orderStmt->execute([
            'invoice_number' => invoiceNumber(),
            'customer_id' => $customerId,
            'created_by' => (int) $auth['id'],
            'service_type_id' => (int) $service['id'],
            'laundry_weight_kg' => $weight,
            'price_per_kg_snapshot' => $pricePerKg,
            'subtotal_kg' => $subtotalKg,
            'grand_total' => $subtotalKg,
            'payment_status' => 'belum_lunas',
            'current_status' => 'DITERIMA',
            'notes' => isset($data['notes']) ? (string) $data['notes'] : null,
        ]);

        $orderId = (int) db()->lastInsertId();
        $specialSubtotal = 0;

        $specialItems = $data['special_items'] ?? [];
        if (is_array($specialItems)) {
            foreach ($specialItems as $item) {
                if (!is_array($item) || !isset($item['special_item_category_id'], $item['quantity'])) {
                    continue;
                }

                $catStmt = db()->prepare(
                    'SELECT id, name, unit, price_per_item
                     FROM special_item_categories
                     WHERE id = :id
                     LIMIT 1'
                );
                $catStmt->execute(['id' => (int) $item['special_item_category_id']]);
                $cat = $catStmt->fetch();
                if (!$cat) {
                    continue;
                }

                $quantity = max(1, (int) $item['quantity']);
                $subtotal = ((int) $cat['price_per_item']) * $quantity;
                $specialSubtotal += $subtotal;

                $itemStmt = db()->prepare(
                    'INSERT INTO order_special_items (
                        order_id, special_item_category_id, category_name_snapshot,
                        unit_snapshot, price_per_item_snapshot, quantity, subtotal, created_at, updated_at
                    ) VALUES (
                        :order_id, :special_item_category_id, :category_name_snapshot,
                        :unit_snapshot, :price_per_item_snapshot, :quantity, :subtotal, NOW(), NOW()
                    )'
                );
                $itemStmt->execute([
                    'order_id' => $orderId,
                    'special_item_category_id' => (int) $cat['id'],
                    'category_name_snapshot' => $cat['name'],
                    'unit_snapshot' => $cat['unit'],
                    'price_per_item_snapshot' => (int) $cat['price_per_item'],
                    'quantity' => $quantity,
                    'subtotal' => $subtotal,
                ]);
            }
        }

        $updateStmt = db()->prepare(
            'UPDATE orders
             SET subtotal_special = :subtotal_special, grand_total = :grand_total, updated_at = NOW()
             WHERE id = :id'
        );
        $updateStmt->execute([
            'subtotal_special' => $specialSubtotal,
            'grand_total' => $subtotalKg + $specialSubtotal,
            'id' => $orderId,
        ]);

        $statusStmt = db()->prepare(
            'INSERT INTO order_status_logs (order_id, previous_status, new_status, changed_by, changed_at, created_at, updated_at)
             VALUES (:order_id, :previous_status, :new_status, :changed_by, NOW(), NOW(), NOW())'
        );
        $statusStmt->execute([
            'order_id' => $orderId,
            'previous_status' => null,
            'new_status' => 'DITERIMA',
            'changed_by' => (int) $auth['id'],
        ]);

        db()->commit();

        jsonResponse(orderDto($orderId), 201);
    }

    if ($method === 'GET' && preg_match('#^/api/v1/customer/invoices/([^/]+)$#', $path, $matches) === 1) {
        $auth = requireAuth();
        requireRole($auth, ['customer']);

        $invoice = $matches[1];
        $customerId = findCustomerIdByUserId((int) $auth['id']);
        if ($customerId === null) {
            jsonResponse(['message' => 'Profil customer tidak ditemukan'], 422);
        }

        $stmt = db()->prepare('SELECT id FROM orders WHERE invoice_number = :invoice AND customer_id = :customer_id LIMIT 1');
        $stmt->execute([
            'invoice' => $invoice,
            'customer_id' => $customerId,
        ]);
        $row = $stmt->fetch();

        if (!$row) {
            jsonResponse(['message' => 'Invoice tidak ditemukan'], 404);
        }

        jsonResponse(orderDto((int) $row['id']));
    }

    if ($method === 'POST' && preg_match('#^/api/v1/orders/(\d+)/status-transition$#', $path, $matches) === 1) {
        $auth = requireAuth();
        requireRole($auth, ['staff']);

        $orderId = (int) $matches[1];
        $data = jsonBody();
        $nextStatus = strtoupper(trim((string) ($data['next_status'] ?? '')));
        if ($nextStatus === '') {
            jsonResponse(['message' => 'next_status wajib diisi'], 422);
        }

        $stmt = db()->prepare(
            'SELECT o.id, o.current_status, st.workflow
             FROM orders o
             INNER JOIN service_types st ON st.id = o.service_type_id
             WHERE o.id = :id
             LIMIT 1'
        );
        $stmt->execute(['id' => $orderId]);
        $row = $stmt->fetch();

        if (!$row) {
            jsonResponse(['message' => 'Order tidak ditemukan'], 404);
        }

        $flow = json_decode((string) $row['workflow'], true);
        if (!is_array($flow)) {
            $flow = [];
        }

        $current = (string) $row['current_status'];
        $currentIndex = array_search($current, $flow, true);
        $nextIndex = array_search($nextStatus, $flow, true);
        $valid = is_int($currentIndex) && is_int($nextIndex) && $nextIndex === $currentIndex + 1;

        if (!$valid) {
            jsonResponse([
                'message' => 'Transisi status tidak valid',
                'current_status' => $current,
                'allowed_flow' => $flow,
            ], 422);
        }

        $update = 'UPDATE orders SET current_status = :status, updated_at = NOW()';
        if ($nextStatus === 'SELESAI') {
            $update .= ', completed_at = NOW()';
        }
        if ($nextStatus === 'DIAMBIL') {
            $update .= ', picked_up_at = NOW()';
        }
        $update .= ' WHERE id = :id';

        $updateStmt = db()->prepare($update);
        $updateStmt->execute([
            'status' => $nextStatus,
            'id' => $orderId,
        ]);

        $logStmt = db()->prepare(
            'INSERT INTO order_status_logs (order_id, previous_status, new_status, changed_by, changed_at, created_at, updated_at)
             VALUES (:order_id, :previous_status, :new_status, :changed_by, NOW(), NOW(), NOW())'
        );
        $logStmt->execute([
            'order_id' => $orderId,
            'previous_status' => $current,
            'new_status' => $nextStatus,
            'changed_by' => (int) $auth['id'],
        ]);

        jsonResponse(['message' => 'Status berhasil diperbarui', 'order' => orderDto($orderId)]);
    }

    if ($method === 'POST' && preg_match('#^/api/v1/orders/(\d+)/payment-verify$#', $path, $matches) === 1) {
        $auth = requireAuth();
        requireRole($auth, ['staff']);

        $orderId = (int) $matches[1];
        $data = jsonBody();

        $stmt = db()->prepare('SELECT id, payment_status, grand_total FROM orders WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $orderId]);
        $order = $stmt->fetch();

        if (!$order) {
            jsonResponse(['message' => 'Order tidak ditemukan'], 404);
        }

        if ((string) $order['payment_status'] === 'lunas') {
            jsonResponse(['message' => 'Order sudah lunas'], 422);
        }

        $amountPaid = isset($data['amount_paid']) ? (int) $data['amount_paid'] : (int) $order['grand_total'];

        $logStmt = db()->prepare(
            'INSERT INTO payment_logs (
                order_id, previous_status, new_status, amount_paid, verified_by, verified_at, notes, created_at, updated_at
            ) VALUES (
                :order_id, :previous_status, :new_status, :amount_paid, :verified_by, NOW(), :notes, NOW(), NOW()
            )'
        );
        $logStmt->execute([
            'order_id' => $orderId,
            'previous_status' => 'belum_lunas',
            'new_status' => 'lunas',
            'amount_paid' => max(0, $amountPaid),
            'verified_by' => (int) $auth['id'],
            'notes' => isset($data['notes']) ? (string) $data['notes'] : null,
        ]);

        $updateStmt = db()->prepare('UPDATE orders SET payment_status = :status, updated_at = NOW() WHERE id = :id');
        $updateStmt->execute([
            'status' => 'lunas',
            'id' => $orderId,
        ]);

        jsonResponse(['message' => 'Pembayaran berhasil diverifikasi', 'order' => orderDto($orderId)]);
    }

    if ($method === 'POST' && $path === '/api/v1/complaints') {
        $auth = requireAuth();
        requireRole($auth, ['customer']);

        $data = jsonBody();
        foreach (['invoice_number', 'item_name', 'damage_type'] as $key) {
            if (!isset($data[$key]) || trim((string) $data[$key]) === '') {
                jsonResponse(['message' => $key . ' wajib diisi'], 422);
            }
        }

        $customerId = findCustomerIdByUserId((int) $auth['id']);
        if ($customerId === null) {
            jsonResponse(['message' => 'Profil customer tidak ditemukan'], 422);
        }

        $orderStmt = db()->prepare(
            'SELECT id FROM orders
             WHERE invoice_number = :invoice_number AND customer_id = :customer_id
             LIMIT 1'
        );
        $orderStmt->execute([
            'invoice_number' => (string) $data['invoice_number'],
            'customer_id' => $customerId,
        ]);
        $order = $orderStmt->fetch();

        if (!$order) {
            jsonResponse(['message' => 'Invoice tidak ditemukan atau bukan milik Anda'], 404);
        }

        $insert = db()->prepare(
            'INSERT INTO complaints (
                order_id, customer_id, item_name, damage_type, description, status, created_at, updated_at
            ) VALUES (
                :order_id, :customer_id, :item_name, :damage_type, :description, :status, NOW(), NOW()
            )'
        );
        $insert->execute([
            'order_id' => (int) $order['id'],
            'customer_id' => $customerId,
            'item_name' => trim((string) $data['item_name']),
            'damage_type' => trim((string) $data['damage_type']),
            'description' => isset($data['description']) ? trim((string) $data['description']) : null,
            'status' => 'submitted',
        ]);

        jsonResponse(['message' => 'Komplain berhasil dibuat'], 201);
    }

    jsonResponse(['message' => 'Not Found'], 404);
} catch (Throwable $e) {
    $debug = filter_var(env('APP_DEBUG', 'false'), FILTER_VALIDATE_BOOLEAN);
    jsonResponse([
        'message' => 'Internal Server Error',
        'error' => $debug ? $e->getMessage() : null,
    ], 500);
}

