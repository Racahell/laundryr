CREATE DATABASE IF NOT EXISTS laundryr CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE laundryr;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(25) NULL,
    role ENUM('admin', 'staff', 'customer') NOT NULL DEFAULT 'customer',
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NULL,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(25) NOT NULL,
    address TEXT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    CONSTRAINT fk_customers_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS service_types (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    workflow JSON NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS service_prices (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    service_type_id BIGINT UNSIGNED NOT NULL,
    price_per_kg INT UNSIGNED NOT NULL,
    effective_from DATE NOT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    UNIQUE KEY uniq_service_price (service_type_id, effective_from),
    CONSTRAINT fk_service_prices_service_type FOREIGN KEY (service_type_id) REFERENCES service_types(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS special_item_categories (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    unit VARCHAR(40) NOT NULL DEFAULT 'item',
    price_per_item INT UNSIGNED NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    customer_id BIGINT UNSIGNED NOT NULL,
    created_by BIGINT UNSIGNED NOT NULL,
    service_type_id BIGINT UNSIGNED NOT NULL,
    laundry_weight_kg DECIMAL(8,2) NOT NULL DEFAULT 0,
    price_per_kg_snapshot INT UNSIGNED NOT NULL DEFAULT 0,
    subtotal_kg INT UNSIGNED NOT NULL DEFAULT 0,
    subtotal_special INT UNSIGNED NOT NULL DEFAULT 0,
    grand_total INT UNSIGNED NOT NULL DEFAULT 0,
    payment_status ENUM('belum_lunas', 'lunas') NOT NULL DEFAULT 'belum_lunas',
    current_status VARCHAR(50) NOT NULL DEFAULT 'DITERIMA',
    completed_at TIMESTAMP NULL,
    picked_up_at TIMESTAMP NULL,
    notes TEXT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    CONSTRAINT fk_orders_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_orders_service_type FOREIGN KEY (service_type_id) REFERENCES service_types(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_special_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NOT NULL,
    special_item_category_id BIGINT UNSIGNED NOT NULL,
    category_name_snapshot VARCHAR(255) NOT NULL,
    unit_snapshot VARCHAR(40) NOT NULL DEFAULT 'item',
    price_per_item_snapshot INT UNSIGNED NOT NULL,
    quantity INT UNSIGNED NOT NULL,
    subtotal INT UNSIGNED NOT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    CONSTRAINT fk_order_special_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_order_special_items_category FOREIGN KEY (special_item_category_id) REFERENCES special_item_categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_status_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NOT NULL,
    previous_status VARCHAR(50) NULL,
    new_status VARCHAR(50) NOT NULL,
    changed_by BIGINT UNSIGNED NOT NULL,
    changed_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    CONSTRAINT fk_order_status_logs_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_order_status_logs_user FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payment_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NOT NULL,
    previous_status ENUM('belum_lunas', 'lunas') NOT NULL,
    new_status ENUM('belum_lunas', 'lunas') NOT NULL,
    amount_paid INT UNSIGNED NOT NULL,
    verified_by BIGINT UNSIGNED NOT NULL,
    verified_at TIMESTAMP NOT NULL,
    notes TEXT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    CONSTRAINT fk_payment_logs_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_payment_logs_user FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS complaints (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NOT NULL,
    customer_id BIGINT UNSIGNED NOT NULL,
    item_name VARCHAR(255) NOT NULL,
    damage_type VARCHAR(255) NOT NULL,
    description TEXT NULL,
    photo_url VARCHAR(255) NULL,
    status ENUM('submitted', 'in_review', 'resolved', 'rejected') NOT NULL DEFAULT 'submitted',
    reviewed_by BIGINT UNSIGNED NULL,
    reviewed_at TIMESTAMP NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    CONSTRAINT fk_complaints_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_complaints_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    CONSTRAINT fk_complaints_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS api_tokens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    token CHAR(64) NOT NULL UNIQUE,
    revoked_at TIMESTAMP NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL,
    CONSTRAINT fk_api_tokens_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO users (name, email, phone, role, password, created_at, updated_at)
SELECT 'Admin Laundryr', 'admin@gmail.com', '081111111111', 'admin', '$2y$10$cxCXu/cpvvtLHLRaXgF4kexXvEFl06RraGe6oyJ.qM.JZmV0JxtZa', NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'admin@gmail.com');

INSERT INTO users (name, email, phone, role, password, created_at, updated_at)
SELECT 'Petugas Laundryr', 'petugas@gmail.com', '082222222222', 'staff', '$2y$10$cxCXu/cpvvtLHLRaXgF4kexXvEFl06RraGe6oyJ.qM.JZmV0JxtZa', NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'petugas@gmail.com');

INSERT INTO users (name, email, phone, role, password, created_at, updated_at)
SELECT 'Pelanggan Demo', 'pelanggan@gmail.com', '083333333333', 'customer', '$2y$10$cxCXu/cpvvtLHLRaXgF4kexXvEFl06RraGe6oyJ.qM.JZmV0JxtZa', NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'pelanggan@gmail.com');

INSERT INTO customers (user_id, name, phone, address, created_at, updated_at)
SELECT u.id, u.name, u.phone, 'Alamat pelanggan demo', NOW(), NOW()
FROM users u
WHERE u.email = 'pelanggan@gmail.com'
  AND NOT EXISTS (SELECT 1 FROM customers c WHERE c.user_id = u.id);

INSERT INTO service_types (code, name, workflow, is_active, created_at, updated_at)
SELECT 'FULL_LAUNDRY', 'Full Laundry', JSON_ARRAY('DITERIMA','DICUCI','DIJEMUR','DISETRIKA','SELESAI','DIAMBIL'), 1, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM service_types WHERE code = 'FULL_LAUNDRY');

INSERT INTO service_types (code, name, workflow, is_active, created_at, updated_at)
SELECT 'SETRIKA_SAJA', 'Setrika Saja', JSON_ARRAY('DITERIMA','DISETRIKA','SELESAI','DIAMBIL'), 1, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM service_types WHERE code = 'SETRIKA_SAJA');

INSERT INTO service_prices (service_type_id, price_per_kg, effective_from, created_at, updated_at)
SELECT st.id, 7000, CURDATE(), NOW(), NOW()
FROM service_types st
WHERE st.code = 'FULL_LAUNDRY'
  AND NOT EXISTS (SELECT 1 FROM service_prices sp WHERE sp.service_type_id = st.id AND sp.effective_from = CURDATE());

INSERT INTO service_prices (service_type_id, price_per_kg, effective_from, created_at, updated_at)
SELECT st.id, 6000, CURDATE(), NOW(), NOW()
FROM service_types st
WHERE st.code = 'SETRIKA_SAJA'
  AND NOT EXISTS (SELECT 1 FROM service_prices sp WHERE sp.service_type_id = st.id AND sp.effective_from = CURDATE());

INSERT INTO special_item_categories (name, unit, price_per_item, is_active, created_at, updated_at)
VALUES
('Selimut', 'buah', 18000, 1, NOW(), NOW()),
('Bed cover', 'buah', 25000, 1, NOW(), NOW()),
('Sprei', 'lembar', 15000, 1, NOW(), NOW()),
('Gorden', 'lembar', 20000, 1, NOW(), NOW()),
('Sepatu', 'pasang', 30000, 1, NOW(), NOW()),
('Tas', 'buah', 22000, 1, NOW(), NOW()),
('Boneka', 'buah', 16000, 1, NOW(), NOW()),
('Jaket Tebal', 'buah', 17000, 1, NOW(), NOW()),
('Karpet Kecil', 'buah', 35000, 1, NOW(), NOW())
ON DUPLICATE KEY UPDATE
unit = VALUES(unit),
price_per_item = VALUES(price_per_item),
is_active = VALUES(is_active),
updated_at = NOW();

