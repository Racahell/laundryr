<?php

declare(strict_types=1);

date_default_timezone_set('Asia/Jakarta');

function loadEnv(string $path): void
{
    if (!is_file($path)) return;
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) return;

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        if ($key === '') continue;
        $_ENV[$key] = $value;
        putenv($key . '=' . $value);
    }
}

function env(string $key, ?string $default = null): ?string
{
    $value = $_ENV[$key] ?? getenv($key);
    if ($value === false || $value === null || $value === '') return $default;
    return (string) $value;
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', env('DB_HOST', '127.0.0.1'), env('DB_PORT', '3306'), env('DB_DATABASE', 'laundryr'));
    $pdo = new PDO($dsn, env('DB_USERNAME', 'root'), env('DB_PASSWORD', ''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    return $pdo;
}

function jsonBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') return [];
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function jsonResponse(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

function bearerToken(): ?string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if ($header === '' && function_exists('getallheaders')) {
        $headers = getallheaders();
        $header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }
    if (!preg_match('/^Bearer\s+(.+)$/i', $header, $matches)) return null;
    return trim($matches[1]);
}

function requireAuth(): array
{
    $token = bearerToken();
    if ($token === null) jsonResponse(['message' => 'Unauthorized'], 401);

    $stmt = db()->prepare('SELECT u.id, u.name, u.email, u.phone, u.role, t.id AS token_id FROM api_tokens t INNER JOIN users u ON u.id = t.user_id WHERE t.token = :token AND t.revoked_at IS NULL LIMIT 1');
    $stmt->execute(['token' => $token]);
    $user = $stmt->fetch();
    if (!$user) jsonResponse(['message' => 'Unauthorized'], 401);
    return $user;
}

function requireRole(array $user, array $allowed): void
{
    if (!in_array($user['role'], $allowed, true)) jsonResponse(['message' => 'Forbidden'], 403);
}

function userDto(array $user): array
{
    return [
        'id' => (int) $user['id'],
        'name' => $user['name'],
        'email' => $user['email'],
        'phone' => $user['phone'],
        'role' => $user['role'],
    ];
}

function tokenForUser(int $userId): string
{
    $token = bin2hex(random_bytes(32));
    db()->prepare('INSERT INTO api_tokens (user_id, token, created_at, updated_at) VALUES (:user_id, :token, NOW(), NOW())')->execute(['user_id' => $userId, 'token' => $token]);
    return $token;
}

function findCustomerIdByUserId(int $userId): ?int
{
    $stmt = db()->prepare('SELECT id FROM customers WHERE user_id = :user_id LIMIT 1');
    $stmt->execute(['user_id' => $userId]);
    $row = $stmt->fetch();
    return $row ? (int) $row['id'] : null;
}

function invoiceNumber(): string
{
    $prefix = 'INV-' . date('Ymd');
    $total = (int) (db()->query('SELECT COUNT(*) AS total FROM orders WHERE DATE(created_at) = CURDATE()')->fetch()['total'] ?? 0) + 1;
    return sprintf('%s-%04d', $prefix, $total);
}

function orderDto(int $orderId): array
{
    $stmt = db()->prepare('SELECT o.*, c.id AS c_id, c.name AS c_name, c.phone AS c_phone, c.address AS c_address, st.id AS st_id, st.code AS st_code, st.name AS st_name FROM orders o INNER JOIN customers c ON c.id = o.customer_id INNER JOIN service_types st ON st.id = o.service_type_id WHERE o.id = :id LIMIT 1');
    $stmt->execute(['id' => $orderId]);
    $order = $stmt->fetch();
    if (!$order) jsonResponse(['message' => 'Order tidak ditemukan'], 404);

    $itemsStmt = db()->prepare('SELECT id, category_name_snapshot, unit_snapshot, price_per_item_snapshot, quantity, subtotal FROM order_special_items WHERE order_id = :id ORDER BY id ASC');
    $itemsStmt->execute(['id' => $orderId]);
    $items = $itemsStmt->fetchAll();

    $overdue = false;
    if ($order['completed_at'] !== null && $order['picked_up_at'] === null) {
        $overdue = (new DateTimeImmutable($order['completed_at']))->diff(new DateTimeImmutable('now'))->days > 30;
    }

    return [
        'id' => (int) $order['id'],
        'invoice_number' => $order['invoice_number'],
        'customer' => [
            'id' => (int) $order['c_id'],
            'name' => $order['c_name'],
            'phone' => $order['c_phone'],
            'address' => $order['c_address'],
        ],
        'service_type' => [
            'id' => (int) $order['st_id'],
            'code' => $order['st_code'],
            'name' => $order['st_name'],
        ],
        'laundry_weight_kg' => (float) $order['laundry_weight_kg'],
        'subtotal_kg' => (int) $order['subtotal_kg'],
        'subtotal_special' => (int) $order['subtotal_special'],
        'grand_total' => (int) $order['grand_total'],
        'payment_status' => $order['payment_status'],
        'current_status' => $order['current_status'],
        'overdue_unclaimed' => $overdue,
        'special_items' => array_map(static fn(array $item): array => [
            'id' => (int) $item['id'],
            'category_name_snapshot' => $item['category_name_snapshot'],
            'unit_snapshot' => $item['unit_snapshot'],
            'price_per_item_snapshot' => (int) $item['price_per_item_snapshot'],
            'quantity' => (int) $item['quantity'],
            'subtotal' => (int) $item['subtotal'],
        ], $items),
    ];
}

loadEnv(dirname(__DIR__) . DIRECTORY_SEPARATOR . '.env');
